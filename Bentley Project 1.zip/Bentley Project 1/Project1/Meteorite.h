//
// Created by Lauren Bentley on 1/24/22.
//

#ifndef PROJECT1_METEORITE_H
#define PROJECT1_METEORITE_H

#include <string>
#include <iostream>
#include <ostream>
#include <iomanip>
#include <fstream>
#include <vector>

using std::string, std::vector, std::cout, std::ifstream, std::ostream;
using std::left, std::setw;

class Meteorite {

private:
    string name, recclass;
    int id, year;
    double mass;

public:
    // Constructors
    Meteorite() { // default
        name = "Unnamed";
        id = 0;
        recclass = "Unknown";
        mass = 0;
        year = 0;
    }
    Meteorite (string name, int id, string recclass, int mass, int year) {
        this->name = name;
        this->id = id;
        this->recclass = recclass;
        this->mass = mass;
        this->year = year;
    }

    // Getters
    string getName() const {
        return name;
    }
    int getID() const {
        return id;
    }
    string getRecclass() const {
        return recclass;
    }
    double getMass() const {
        return mass;
    }
    int getYear() const {
        return year;
    }

    // Setters
    void setName(string name) {
        this->name = name;
    }
    void setID(int id) {
        this->id = id;
    }
    void setRecclass(string recclass) {
        this->recclass = recclass;
    }
    void setMass(int mass) {
        this->mass = mass;
    }
    void setYear(int year) {
        this->year = year;
    }

    // overloaded operators
    friend ostream& operator << (ostream& outs, const Meteorite& meteorite) {

        outs << left << setw(40) << meteorite.getName();
        outs << left << setw(20) << meteorite.getID();
        outs << left << setw(20) << meteorite.getRecclass();
        outs << left << setw(10) << meteorite.getMass();
        outs << left << setw(10) << meteorite.getYear();

        return outs;

    }

    friend bool operator == (const Meteorite& meteor1, const Meteorite& meteor2) {

        // Only need to check the unique attribute
        return meteor1.getID() == meteor2.getID();


    }

};

void getData(string fileName, vector<Meteorite>& meteorites){

    ifstream fileIn;
    fileIn.open(fileName);

    // Deals with first two rows of data (which are file title and column names)

    string header;
    string cols;
    char comma = ',';

    if (fileIn) {
        getline(fileIn, header);
        getline(fileIn, cols);
    }

    // Variables for meteorite class
    string name, recclass;
    int id, year;
    double mass;

    // Reading in data
    while (fileIn && fileIn.peek() != EOF ) {

        // Get name
        getline(fileIn, name, ',');

        // Get id
        fileIn >> id >> comma;

        // Get recclass
        getline(fileIn, recclass, ',');

        // Get mass
        fileIn >> mass >> comma;

        // Get year
        fileIn >> year;

        // Add to vector
        meteorites.push_back(Meteorite(name, id, recclass, mass, year));

    }

    fileIn.close();

}


    // 2nd Global function: findInYear
    // Finds the total number of meteorites from a given year

vector<Meteorite> findInYear(vector<Meteorite>& inYear, vector<Meteorite>& meteorites, int year) {

    int total = 0;

    for (int i = 0 ; i < meteorites.size() ; i++ ) {
        if ( meteorites[i].getYear() == year ) {
            total++;
            inYear.push_back(meteorites[i]);
        }
    }

    return inYear;

}

// 

#endif //PROJECT1_METEORITE_H
