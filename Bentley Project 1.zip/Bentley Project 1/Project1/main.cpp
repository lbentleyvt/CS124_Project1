#include <iomanip>
#include "Meteorite.h"
using namespace std;

int main() {

    vector<Meteorite> meteorites;
    getData("../Meteorite Landings.csv", meteorites);

    // Printing out data from meteorites vector
    for ( int i = 0; i < meteorites.size() ; ++i ) {
        cout << meteorites[i];
    }

    // Comparing IDs of meteorites
    /**
    cout << boolalpha << endl << endl;
    cout << "Is Aachen == Aachen? " << (meteorites[0] == meteorites[0]) << endl; // Should be TRUE
    cout << "Is Aachen == Aarhus? " << (meteorites[0] == meteorites[1]) << endl; // Should be FALSE
     */

    // inYear function — global function which finds the meteorites in a given year

    int year; // User submitted year
    vector<Meteorite> inYear; // Will store meteorites of given year

    cout << "\nEnter year to find meteorite data: ";
    cin >> year;

    // Calling global function
    inYear = findInYear(inYear, meteorites, year);

    // Output for findInYear

    cout << "There were " << inYear.size() << " meteorites found in the year " << year << "." << endl;

    for ( int x = 0 ; x < inYear.size() ; x++ ) {
        cout << inYear[x].getName() << ", ID: " << inYear[x].getID();
    }

}
